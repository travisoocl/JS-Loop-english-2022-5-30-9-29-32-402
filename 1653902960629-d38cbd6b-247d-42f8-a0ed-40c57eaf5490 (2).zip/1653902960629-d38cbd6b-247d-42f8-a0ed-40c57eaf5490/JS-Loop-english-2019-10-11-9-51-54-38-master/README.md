# JS-loop

This exercise consists of several small exercises, each with its own readme, which you can check out.

## requirement
- fork this repository. 
- Complete the job according to the readme requirements
- Submit the job to github and submit the github address back to the system

